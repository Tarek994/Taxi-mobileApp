String fromGraphQLConnectionCursorToDartString(String data) => data;
String fromDartStringToGraphQLConnectionCursor(String data) => data;

String? fromGraphQLConnectionCursorToDartStringNullable(String? data) => data;
String? fromDartStringToGraphQLConnectionCursorNullable(String? data) => data;

String? fromGraphQLConnectionCursorNullableToDartStringNullable(String? data) =>
    data;
String? fromDartStringNullableToGraphQLConnectionCursorNullable(String? data) =>
    data;
